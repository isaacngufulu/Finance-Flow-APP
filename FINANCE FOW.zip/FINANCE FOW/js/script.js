"use strict";

// SELECIONANDO ELEMENTOS DOM
const c = console.log.bind(document);
const labelSumIn = document.querySelector(".op__in");
const labelSumOut = document.querySelector(".op__out");
const labelSumTot = document.querySelector(".op__tot");
const labelWelcome = document.querySelector(".greet-user");

const inputExpenseName = document.querySelector(".expense_name");
const inputExpenseValue = document.querySelector(".expense_value");
const inputExpenseName2 = document.querySelector(".expense_name-2");
const inputExpenseValue2 = document.querySelector(".expense_value-2");
const inputExpenseTypeIn = document.querySelector(".check_in");
const inputExpenseTypeOut = document.querySelector(".check_out");
const inputLoginUser = document.querySelector(".user-input");
const inputLoginPassword = document.querySelector(".password-input");
const inputCreateName = document.querySelector(".input-create-name");
const inputCreateUser = document.querySelector(".input-create-user");
const inputCreatePassword = document.querySelector(".password-create");

const btnAddExpense = document.querySelector(".add");
const btnAddExpenseMobile = document.querySelector(".btn-add-mobile");
const btnLogin = document.querySelector(".btn-login");
const btnLoginAcc = document.querySelector(".login-acc");
const btnSeePassword = document.querySelectorAll(".btn-see-password");
const btnCreate = document.querySelector(".btn-create");
const btnCreateAcc = document.querySelector(".create-acc");
const btnLogout = document.querySelector(".logout-box");
const addMobile2 = document.querySelector(".add-2");
const btnYes = document.querySelector(".yes");
const btnNo = document.querySelector(".no");
const btnCloseEdit = document.querySelectorAll(".close_edit_box");
const btnEditExpense = document.querySelector(".edit_expense");

const containerRows = document.querySelector(".expenses-rows-box");
const rows = document.querySelector(".expenses-row");
const appContainer = document.querySelector(".app-container");
const loginContainer = document.querySelector(".login_start");
const createContainer = document.querySelector(".login_create");
const overlay = document.querySelector(".overlay");
const deleteExpenseBox = document.querySelector(".delete-box");
const editBox = document.querySelector(".edit-box");
const editCtaBox = document.querySelector(".edit_cta-box");

let accounts = localStorage.getItem("accounts")
  ? JSON.parse(localStorage.getItem("accounts"))
  : [];
console.log(accounts);

let currentAccount;
let type = "";
let currentExpense;

// FUNCTIONS
// Função para salvar as contas no localStorage
function saveAccounts() {
  localStorage.setItem("accounts", JSON.stringify(accounts));
}

// ATUALIZANDO O BALANÇO
labelSumIn.textContent = 0;
labelSumOut.textContent = 0;
labelSumTot.textContent = 0;
const calcBalance = function (curr) {};

// Adicionar dispesas
const expensesRows = function () {
  containerRows.innerHTML = "";
  currentAccount.allExpenses.forEach((exp) => {
    const expenseType = exp.type === "entrada" ? "in" : "out";
    const expenseIcon = exp.type === "saída" ? "down" : "up";

    const html = `
      <div class="expenses-row" data-id="${exp.id}">
        <span class="des">${exp.name}</span>
        <span class="val ${expenseType}">${curr(exp.value)}</span>
        <span class="tip">
          <ion-icon
            class="expense__icon ${expenseType}"
            name="arrow-${expenseIcon}-circle-outline">
          </ion-icon>
        </span>
        <button class="delete">
          <ion-icon class="remove" name="trash"></ion-icon>
        </button>
      </div>`;

    containerRows.insertAdjacentHTML("afterbegin", html);

    saveAccounts();
    function curr(gg) {
      return new Intl.NumberFormat("pt-pt").format(exp.value);
    }

    if (containerRows.innerHTML === "") {
      document.querySelector(".expenses-info").classList.add("hidden");
    } else {
      document.querySelector(".expenses-info").classList.remove("hidden");
    }
  });
};

const expensesRows2 = function () {
  containerRows.innerHTML = "";
  currentAccount.allExpenses.forEach((exp) => {
    const expenseType = exp.type === "entrada" ? "in" : "out";
    const expenseIcon = exp.type === "saída" ? "down" : "up";

    const html = `
      <div class="expenses-row" data-id="${exp.id}">
        <span class="des">${exp.name}</span>
        <span class="val ${expenseType}">${curr(exp.value)}</span>
        <span class="tip">
          <ion-icon
            class="expense__icon ${expenseType}"
            name="arrow-${expenseIcon}-circle-outline">
          </ion-icon>
        </span>
        <button class="delete">
          <ion-icon class="remove" name="trash"></ion-icon>
        </button>
      </div>`;

    containerRows.insertAdjacentHTML("afterbegin", html);

    saveAccounts();

    function curr(gg) {
      return new Intl.NumberFormat("pt-pt").format(exp.value);
    }

    if (containerRows.innerHTML === "") {
      document.querySelector(".expenses-info").classList.add("hidden");
    } else {
      document.querySelector(".expenses-info").classList.remove("hidden");
    }
  });
};

// INICIANDO SESSÃO
btnLogin.addEventListener("click", function (e) {
  e.preventDefault();

  if (containerRows.innerHTML === "") {
    document.querySelector(".expenses-info").classList.add("hidden");
  } else {
    document.querySelector(".expenses-info").classList.remove("hidden");
  }

  const loginUsername = inputLoginUser.value;
  const loginPassword = +inputLoginPassword.value;
  console.log(loginPassword);

  currentAccount = accounts.find((acc) => acc.username === loginUsername);

  if (inputLoginPassword.value === "" || inputLoginUser.value === "") {
    alert("Por favor, preencha todos os campos");
  } else if (
    loginUsername === currentAccount?.username &&
    loginPassword === currentAccount?.password
  ) {
    console.log(currentAccount);
    appContainer.classList.remove("hidden");
    loginContainer.classList.add("hidden");
  } else {
    alert("Credências erradas, tente novamente");
  }

  const welcome = currentAccount.fullName.split(" ")[0];
  labelWelcome.textContent = `Bem Vindo de volta, ${welcome}`;

  inputLoginPassword.value = inputLoginUser.value = "";
  expensesRows();

  calcBalance(currentAccount.allExpenses);
});

// ALTERNAR ENTRE CRIAR E INICIAR
// createContainer.classList.add("hidden");
// appContainer.classList.add("hidden");
btnCreateAcc.addEventListener("click", function (e) {
  e.preventDefault();
  loginContainer.classList.remove("hidden");
  createContainer.classList.add("hidden");
});

btnLoginAcc.addEventListener("click", function (e) {
  e.preventDefault();
  loginContainer.classList.add("hidden");
  createContainer.classList.remove("hidden");
});

// CRIANDO UMA NOVA CONTA
btnCreate.addEventListener("click", function (e) {
  e.preventDefault();
  const fullName = inputCreateName.value;
  const username = inputCreateUser.value;
  const password = +inputCreatePassword.value;

  if (
    inputCreateName.value === "" ||
    inputCreateUser.value === "" ||
    inputCreatePassword.value === ""
  ) {
    alert("Por favor, preencha todos os campos");
  } else if (accounts.find((acc) => acc.username === username)) {
    alert("Usuário já existe");
  } else if (
    fullName &&
    username &&
    password &&
    fullName.includes(" ")
    // password === "number"
  ) {
    const account = {
      fullName: fullName,
      username: username,
      password: password,
      allExpenses: [],
    };
    accounts.push(account);
    saveAccounts();
    alert("A sua conta foi criada com sucesso");
    createContainer.classList.add("hidden");
    loginContainer.classList.remove("hidden");
  } else {
    alert("Credenciais inválidas");
  }

  inputCreateName.value =
    inputCreatePassword.value =
    inputCreateUser.value =
      "";
});

// MONSTRANDO A PALAVRA PASSE DO USUÁRIO
const loginOff = document.querySelector(".eye-off-outline");
const loginIn = document.querySelector(".eye-outline");
const loginOff1 = document.querySelector(".eye-off-outline--1");
const loginIn1 = document.querySelector(".eye-outline--1");

btnSeePassword.forEach((see) => {
  see.addEventListener("click", function (e) {
    e.preventDefault();
    if (inputLoginPassword.type === "password") {
      inputLoginPassword.type = "text";
      loginIn.classList.remove("hidden");
      loginOff.classList.add("hidden");

      inputLoginPassword.value = inputLoginPassword.value;
    } else if (inputLoginPassword.type === "text") {
      inputLoginPassword.type = "password";
      loginIn.classList.add("hidden");
      loginOff.classList.remove("hidden");
    }

    if (inputCreatePassword.type === "password") {
      inputCreatePassword.type = "text";
      loginIn1.classList.remove("hidden");
      loginOff1.classList.add("hidden");

      inputCreatePassword.value = inputCreatePassword.value;
    } else if (inputCreatePassword.type === "text") {
      inputCreatePassword.type = "password";
      loginIn1.classList.add("hidden");
      loginOff1.classList.remove("hidden");
    }
  });
});

// ADICIONANDO NOVAS DISPESAS
containerRows.innerHTML = "";

btnAddExpense.addEventListener("click", function (e) {
  e.preventDefault();

  if (containerRows.innerHTML === "") {
    document.querySelector(".expenses-info").classList.add("hidden");
  } else {
    document.querySelector(".expenses-info").classList.remove("hidden");
  }

  const expenseName = inputExpenseName.value;
  const expenseValue = +inputExpenseValue.value;
  const checkType = type === "input" ? "entrada" : "saída";
  console.log(checkType);

  const expenses = {};
  expenses.type = checkType;

  if (type === "input" && expenseValue !== 0) {
    expenses.value = +expenseValue;
    expenses.id = Math.trunc(Math.random() * 100000000) + 1;
    expenses.name = expenseName;
    currentAccount.allExpenses.push(expenses);
    saveAccounts();
    console.log(currentAccount);
  }

  if (type === "output" && expenseValue !== 0) {
    expenses.value = -expenseValue;
    expenses.id = Math.trunc(Math.random() * 100000000) + 1;
    expenses.name = expenseName;
    currentAccount.allExpenses.push(expenses);
    saveAccounts();
    console.log(currentAccount);
  } else if (inputExpenseName.value === "" || inputExpenseValue.value === "") {
    alert("Por favor, preencha todos os campos");
  }

  inputExpenseName.value = inputExpenseValue.value = "";

  document
    .querySelectorAll(".checkbox")
    .forEach((c) => c.classList.remove("checkbox__active"));

  expensesRows();
  calcBalance(currentAccount.allExpenses);
});

addMobile2.addEventListener("click", function (e) {
  e.preventDefault();

  if (containerRows.innerHTML === "") {
    document.querySelector(".expenses-info").classList.add("hidden");
  } else {
    document.querySelector(".expenses-info").classList.remove("hidden");
  }

  const expenseName = inputExpenseName2.value;
  const expenseValue = +inputExpenseValue2.value;
  const checkType = type === "input" ? "entrada" : "saída";

  const expenses = {};
  expenses.type = checkType;

  if (type === "input" && expenseValue !== 0) {
    expenses.value = +expenseValue;
    expenses.id = Math.trunc(Math.random() * 100000000) + 1;
    expenses.name = expenseName;
    currentAccount.allExpenses.push(expenses);
    saveAccounts();
    console.log(currentAccount);
  }

  if (type === "output" && expenseValue !== 0) {
    expenses.value = -expenseValue;
    expenses.id = Math.trunc(Math.random() * 100000000) + 1;
    expenses.name = expenseName;
    currentAccount.allExpenses.push(expenses);
    saveAccounts();
    console.log(currentAccount);
  } else if (
    inputExpenseName2.value === "" ||
    inputExpenseValue2.value === ""
  ) {
    alert("Por favor, preencha todos os campos");
  }

  inputExpenseName2.value = inputExpenseValue2.value = "";

  document
    .querySelectorAll(".checkbox")
    .forEach((c) => c.classList.remove("checkbox__active"));

  expensesRows2();
  calcBalance(currentAccount.allExpenses);

  overlay.classList.add("hidden");
  document.querySelector(".form-box-2").classList.add("hidden");
});

document.querySelector(".form-box-2").classList.add("hidden");

btnAddExpenseMobile.addEventListener("click", function (e) {
  e.preventDefault();

  document.querySelector(".form-box-2").classList.remove("hidden");
  overlay.classList.remove("hidden");
});

// check box
const btnCheckbox = document.querySelectorAll(".checkbox");
btnCheckbox.forEach((check) => {
  check.addEventListener("click", function (e) {
    e.preventDefault();

    document
      .querySelectorAll(".checkbox")
      .forEach((c) => c.classList.remove("checkbox__active"));

    check.classList.add("checkbox__active");
    type = check.dataset.value;
  });
});

overlay.addEventListener("click", function (e) {
  e.preventDefault();
  document.querySelector(".form-box-2").classList.add("hidden");
  deleteExpenseBox.classList.add("hidden");
  overlay.classList.add("hidden");
  editBox.classList.add("hidden");
  editCtaBox.classList.add("hidden");
});

// TERMINAR SESSÃO
btnLogout.addEventListener("click", function (e) {
  e.preventDefault();
  appContainer.classList.add("hidden");
  loginContainer.classList.remove("hidden");
});

// ELIMINANDO DISPESAS
deleteExpenseBox.classList.add("hidden");
containerRows.addEventListener("click", function (e) {
  e.preventDefault();

  const target = e.target.closest(".remove");
  if (!target) return;

  deleteExpenseBox.classList.remove("hidden");
  overlay.classList.remove("hidden");

  const expense = target.closest(".expenses-row");
  currentExpense = +expense.dataset.id;
  c(expense);
});

btnNo.addEventListener("click", function (e) {
  e.preventDefault();

  deleteExpenseBox.classList.add("hidden");
  overlay.classList.add("hidden");
});

btnYes.addEventListener("click", function (e) {
  e.preventDefault();
  const dele = currentAccount.allExpenses.findIndex(
    (item) => item.id === currentExpense
  );
  c(dele);
  currentAccount.allExpenses.splice(dele, 1);
  expensesRows();
  calcBalance(currentAccount.allExpenses);
  saveAccounts();
  deleteExpenseBox.classList.add("hidden");
  overlay.classList.add("hidden");

  if (containerRows.innerHTML === "") {
    document.querySelector(".expenses-info").classList.add("hidden");
  } else {
    document.querySelector(".expenses-info").classList.remove("hidden");
  }
});
